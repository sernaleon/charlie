Blockly.Python['movemotor'] = function(block) {
  var value_speed = Blockly.Python.valueToCode(block, 'speed', Blockly.Python.ORDER_ATOMIC);
  var dropdown_motor = block.getFieldValue('motor');
  var code = 'moveMotor(',dropdown_motor,',',value_speed')';
  return [code, Blockly.Python.ORDER_FUNCTION_CALL];
};

Blockly.Python['readsonar'] = function(block) {
  var code = 'readSonar()';
  return [code, Blockly.Python.ORDER_FUNCTION_CALL];
};

Blockly.Python['readinfrared'] = function(block) {
  var dropdown_sensor = block.getFieldValue('sensor');
  var code = 'readInfrared(',dropdown_sensor,')';
  return [code, Blockly.Python.ORDER_FUNCTION_CALL];
};