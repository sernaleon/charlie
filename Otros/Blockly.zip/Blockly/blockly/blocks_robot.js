Blockly.Blocks['movemotor'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.appendValueInput("speed")
        .setCheck("Number")
        .appendField("Move motor")
        .appendField(new Blockly.FieldDropdown([["left", "left"], ["right", "right"], ["both", "both"]]), "motor")
        .appendField("at speed (%)");
    this.setInputsInline(true);
    this.setPreviousStatement(true, "null");
    this.setNextStatement(true, "null");
    this.setTooltip('Speed should be between -100% and 100%. Numbers outside [-100,+100] are allowed but dangerous!');
  }
};

Blockly.Blocks['readsonar'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.appendDummyInput()
        .appendField("Read sonar");
    this.setInputsInline(true);
    this.setOutput(true, "Number");
    this.setTooltip('');
  }
};

Blockly.Blocks['readinfrared'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.appendDummyInput()
        .appendField("Read infrared")
        .appendField(new Blockly.FieldDropdown(
		[["1 (Front-left)", "1"], 
		["2", "2"], 
		["3", "3"], 
		["4", "4"], 
		["5", "5"], 
		["6 (Front-middle)", "6"], 
		["7 (Front-middle)", "7"], 
		["8", "8"], 
		["9", "9"], 
		["10", "10"], 
		["11", "11"], 
		["12 (Front-right)", "12"], 
		["13 (Middle-left)", "13"], 
		["14", "14"],
		["15 (Middle-middle)", "15"],
		["16", "16"],
		["17 (Middle-right", "17"]]), "sensor");
    this.setInputsInline(true);
    this.setOutput(true);
    this.setTooltip('');
  }