﻿Globalize.addCultureInfo("default", {
    messages: {
        "tipCalculator": "Tip Calculator",
        "billTotal": "Bill Total",
        "tip": "Tip",
        "split": "Split",
        "totalToPay": "Total to pay",
        "totalPerPerson": "Total per person",
        "totalTip": "Total tip",
        "tipPerPerson": "Tip per person",
        "typeHere": "Type here",
        "roundDown": "Round Down",
        "roundUp": "Round Up"
    }
});
