﻿Globalize.addCultureInfo("fr", {
    messages: {
        "tipCalculator": "Tip Calculator",
        "billTotal": "Facture Totale",
        "tip": "Pointe",
        "split": "Diviser",
        "totalToPay": "Total à payer",
        "totalPerPerson": "Total par personne",
        "totalTip": "pourboire total",
        "tipPerPerson": "Tip par personne",
        "typeHere": "Entrez ici",
        "roundDown": "arrondir vers le bas",
        "roundUp": "rassembler"
    }
});
