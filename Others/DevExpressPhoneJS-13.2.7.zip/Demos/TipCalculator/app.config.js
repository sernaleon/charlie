﻿window.TipCalculator = $.extend(true, window.TipCalculator, {
    "config": {
        "navigationType": "empty"
    }
});
