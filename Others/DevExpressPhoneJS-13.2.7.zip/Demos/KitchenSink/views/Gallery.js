﻿KitchenSink.Gallery = function(params) {
    return {
        data: KitchenSink.db.gallery
    };
};